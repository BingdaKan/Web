var db;
var openRequest = indexedDB.open("smartnote",2);

openRequest.onupgradeneeded = function(e){
	console.log('upgrading...');
	var thisDB = e.target.result;
	if(!thisDB.objectStoreNames.contains("notelist")) {
		thisDB.createObjectStore("notelist", { autoIncrement: true });
	}
};

openRequest.onsuccess = function(e){
	var form = document.getElementById("noteForm");
	console.log('success!');
	db = e.target.result;
	displayNotes();
	form.style.display = "none";
	document.getElementById('btn_new').addEventListener('click', addNote);
	document.getElementById('btn_save').addEventListener('click', saveNote);
	document.getElementById('btn_can').addEventListener('click', cancel);
};

openRequest.onerror = function(e){
	alert("Error", e.target.error.name);
};

function addNote(){
	var btnAdd = document.getElementById('btn_new');
	var btnCan = document.getElementById('btn_can');
	var btnSave = document.getElementById('btn_save');
	var form = document.getElementById("noteForm");
	form.style.display = "block";
	btnAdd.disabled = true;
	btnAdd.style.backgroundColor = "#CCCECB";
	btnCan.disabled = false;
	btnSave.disabled = false;
}

function saveNote(){
	var btnAdd = document.getElementById('btn_new');
	var form = document.getElementById("noteForm");
	var nameInput = document.getElementById("NameText").value;
	var subjectInput = document.getElementById("Sub").value;
	var messageInput = document.getElementById("Msg").value;
	var note = {name: nameInput, subject: subjectInput, message: messageInput, created: new Date()};
	var transaction = db.transaction(['notelist'], 'readwrite');
	var store = transaction.objectStore('notelist');
	var request = store.add(note);
	request.onerror = function(e){
		alert("Error", e.target.error.name);
	};
	request.onsuccess = function(e){
		console.log('Done');
		displayNotes();
		form.style.display = "none";
		btnAdd.disabled = false;
	};
}		

function cancel(){
	var btnSave = document.getElementById('btn_save');
	var btnAdd = document.getElementById('btn_new');
	var btnCan = document.getElementById('btn_can');
	var form = document.getElementById("noteForm");
	form.style.display = "none";
	btnCan.disabled = true;
	btnSave.disabled = false;
	btnAdd.disabled = false;
	btnAdd.style.backgroundColor = "#6CBF24";
}

function removeNote(thisId){    	    	
	var transId = parseInt(thisId);
	var transaction = db.transaction(["notelist"], "readwrite");
	var request = transaction.objectStore("notelist").delete(transId);

    request.onsuccess = function(e) {
    	document.getElementById(thisId).disabled = true;
    	displayNotes();
    };
    request.onerror = function(e){
		alert("Error", e.target.error.name);
	};
};	

function displayNotes() {
	var content = document.getElementById('noteList')
    var transaction = db.transaction(["notelist"], "readonly");
	var objectStore = transaction.objectStore("notelist");
    
    content.innerHTML= "<thead>" + "<tr id='throw'>" + "<th id='thname'>Name</th>" + "<th id='thsub'>Subject</th>" + "<th id ='thdel'></th>" + "</tr>" + "</thead>";
 
    objectStore.openCursor().onsuccess = function(e) {  
    var cursor = e.target.result;  
    if (cursor) { 
        content.innerHTML += "<tbody id = 'tbody_tr" + cursor.key + "'>" + "<tr class = 'briefMsg' id = 'tr" + cursor.key + "' onclick = 'noteDetail(this.id)'>" + "<td class='nameValue'>" + cursor.value.name + "</td>" 
        					+ "<td>" + cursor.value.subject + "</td>" 
        					+ "<td>" + "<button class='btn_del' id='" + cursor.key + "' onclick = 'removeNote(this.id)'>" 
        					+ "<span>Delete</span>"
        					+ "<img src = 'Image_Project1/del_btn.png' class='icon'></button>" + "</td>" + "</tr>"
        					+ "<tr>" + "<td  style='display:none' class = 'time' id ='time_tr" + cursor.key + "'>" + "Created Time: " + cursor.value.created + "</td>" + "</tr>"
        					+ "<tr>" + "<td  style='display:none' class = 'msg' id ='msg_tr" + cursor.key + "'>" + "Content: " + cursor.value.message + "</td>" + "</tr>" + "</tbody>";
        cursor.continue();  
    }  
    else {  
        console.log("no more data found");
     }
    countRow(); 
    };
};

function noteDetail(thisId){
	var transId = thisId;
	var timeStamp = document.getElementById("time_" + transId);
	var msg = document.getElementById("msg_" + transId);
	var tbody = document.getElementById("tbody_" + transId);
	var state = timeStamp.style.display;
	if(state == "none"){
		tbody.style.backgroundColor = "#F7F7F7";
		tbody.style.fontWeight = "700";
		msg.style.fontWeight = "400";
		timeStamp.colSpan = "3";
		timeStamp.style.display = "";
		msg.colSpan = "3";
		msg.style.display = "";
	}else{
		tbody.style.backgroundColor = "#FFF";
		tbody.style.fontWeight = "400";
		timeStamp.style.display = "none";
		msg.style.display = "none";
	}
}

function countRow(){
	var Num = document.getElementById("count");
	var rows = document.getElementById("noteList").getElementsByTagName("button").length;
	Num.innerHTML = "(" + rows + " Notes Total)";
}

(function(document) {
	'use strict';

	var LightTableFilter = (function(Arr) {

		var _input;

		function _onInputEvent(e) {
			_input = e.target;
			var tables = document.getElementsByClassName(_input.getAttribute('data-table'));
			Arr.forEach.call(tables, function(table) {
				Arr.forEach.call(table.tBodies, function(tbody) {
					Arr.forEach.call(tbody.rows, _filter);
				});
			});
		}

		function _filter(row) {
			var text = row.textContent.toLowerCase(), val = _input.value.toLowerCase();
			row.style.display = text.indexOf(val) === -1 ? 'none' : 'table-row';
		}

		return {
			init: function() {
				var inputs = document.getElementsByClassName('light-table-filter');
				Arr.forEach.call(inputs, function(input) {
					input.oninput = _onInputEvent;
				});
			}
		};
	})(Array.prototype);

	document.addEventListener('readystatechange', function() {
		if (document.readyState === 'complete') {
			LightTableFilter.init();
		}
	});

})(document);
